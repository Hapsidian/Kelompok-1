# web-perpustakaan
Aplikasi website perpustakaan sederhana, menggunakan php native
<br>
<p>Aplikasi website berita sederhana yang di buat dengan bahasa program php, javascript, dan menggunakan DBMS (mysql)</p>
<br>
<h3>Fitur Pengeloa Admin Website</h3>
<ul>
	<li>Crud Buku</li>
	<li>Crud Anggota</li>
	<li>Transaksi</li>
	<li>Fitur Kembali Buku Yang Sudah di Pinjam</li>
  <li>Perpanjang masa pinjam buku</li>
  <li>Login, Registrasi & Logout</li>
</ul>
<br>
<h3>Penjelasan fitur</h3>
1. saat mengembalikan buku yang di pinjam, secara otomatis tabel buku akan di tambahkan 1 buku.

2. Saat ingin meminjam buku, secara otomatis di tabel buku di kurangi.
